from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    prompt = ""
    task = "book_idea"

    if request.method == "POST":
        task = request.form["task"]
        prompt = request.form["prompt"]

        if task == "book_idea":
            result = f"Book idea based on '{prompt}': A story of love, conflict, and self-discovery."
        elif task == "outline":
            result = f"Outline for '{prompt}':\n1. Introduction\n2. Conflict\n3. Climax\n4. Resolution"
        elif task == "description":
            result = f"Blurb: Dive into '{prompt}', a gripping tale that explores deep themes with unforgettable characters."
        elif task == "edit_text":
            result = f"Edited version: {prompt.replace('gonna', 'going to').replace('wanna', 'want to')}"

    return render_template("index.html", result=result, prompt=prompt, task=task)

if __name__ == "__main__":
    app.run(debug=True)
