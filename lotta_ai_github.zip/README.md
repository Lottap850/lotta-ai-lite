# Lotta AI Lite

This is a lightweight publishing assistant app designed for GitHub deployment using Flask. It simulates AI-like behavior with templates and simple logic — no API key required.

## Features

- Book idea generator
- Chapter outline creator
- Book blurb writer
- Simple text editor

## How to Run

1. Clone this repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   python main.py
   ```
4. Open your browser and go to `http://localhost:5000`

## Folder Structure

```
.
├── main.py
├── templates/
│   └── index.html
├── requirements.txt
└── README.md
```
